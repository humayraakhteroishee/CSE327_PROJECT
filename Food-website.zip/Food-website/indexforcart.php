<?php include("headerforcart.php");


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<body>

    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-3">

             <form action="managecart.php" method="POST">
              <div class="card">
                <img src="images\dish-1.png" class="card-img-top" >
                <div class="card-body text-center">
                  <h5 class="card-title">Food Item 1</h5>
                  <p class="card-text">Price: $25</p>
                  <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</a>
                  <input type="hidden" name="Item_Name" value="Food Item 1">
                  <input type="hidden" name="Price" value="25">
                </div>
               </div>
             </form>

            </div>

            <div class="col-lg-3">
             <form action="managecart.php" method="POST">
              <div class="card">
                <img src="images\dish-2.png" class="card-img-top" >
                <div class="card-body text-center">
                  <h5 class="card-title">Food Item 2</h5>
                  <p class="card-text">Price: $35</p>
                  <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</a>
                  <input type="hidden" name="Item_Name" value="Food Item 2">
                  <input type="hidden" name="Price" value="35">
                </div>
               </div>
             </form>

            </div>

            <div class="col-lg-3">
             <form action="managecart.php" method="POST">
              <div class="card">
                <img src="images\dish-3.png" class="card-img-top" >
                <div class="card-body text-center">
                  <h5 class="card-title">Food Item 3</h5>
                  <p class="card-text">Price: $35</p>
                  <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</a>
                  <input type="hidden" name="Item_Name" value="Food Item 3">
                  <input type="hidden" name="Price" value="35">
                </div>
               </div>
             </form>

            </div>

            <div class="col-lg-3">
             <form action="managecart.php" method="POST">
              <div class="card">
                <img src="images\dish-4.png" class="card-img-top" >
                <div class="card-body text-center">
                  <h5 class="card-title">Food Item 4</h5>
                  <p class="card-text">Price: $25</p>
                  <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</a>
                  <input type="hidden" name="Item_Name" value="Food Item 4">
                  <input type="hidden" name="Price" value="25">
                </div>
               </div>
             </form>

            </div>

        </div>
    </div>


</body>
</html>
